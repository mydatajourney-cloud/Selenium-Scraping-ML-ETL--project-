from pyspark.sql.functions import udf
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, lit,expr, when, sha2, concat_ws
from pyspark.sql.types import *
import re
from pyspark import SparkFiles
from urllib.parse import urlparse
import IP2Location
from browser.variables import *
import psycopg2
from psycopg2.extras import execute_values

from pyspark.sql.functions import (
    col, date_format, to_date, hour, dayofweek, month, year)

ip_schema = StructType([
    StructField("country", StringType()),
    StructField("region", StringType()),
    StructField("city", StringType())
])
product_dim_schema = StructType([
    StructField("product_id", LongType(), nullable=True),
    StructField("option", ArrayType(
        StructType([
            StructField("option_id", StringType(), nullable=True),
            StructField("option_label", StringType(), nullable=True)
        ])
    ), nullable=True)
])
device_schema = StructType([
    StructField("os", StringType()),
    StructField("browser", StringType()),
    StructField("device_type", StringType())
])

refererurl_schema = StructType([
    StructField("domain", StringType()),
    StructField("full_url", StringType()),
    StructField("source_type",StringType())
])
    
@udf(returnType=refererurl_schema)
def parser_referer(url):
    if url == None:
        return {
            "domain": None,
            "full_url": None,
            "source_type": None
    }

    import sys
    from pyspark import SparkFiles

    sys.path.insert(0, SparkFiles.getRootDirectory())
    from variables import sourceTypeDict
    #rom log import log_bad_referer
    domain = full_url = source_type = "Unknown"
    parsed_url = urlparse(url)
    
    domain = parsed_url.netloc
    full_url = url

    parsed_url = urlparse(full_url)


    try:
        netloc = domain.lower().replace("www.", "")
        parts = netloc.split(".")
        if len(parts) >= 2:
            key = parts[-2] 
        elif parts:
            key = parts[0]
        else: key = None
        source_type = sourceTypeDict[key]
    except Exception: 
        source_type = "Unknown Type"

    return {
        "domain": domain,
        "full_url": url,
        "source_type": source_type
    }



# Define the UDF
@udf(returnType=device_schema)
def parser_user_agent(ua):
    if ua == None:
        return {
            'os': None,
            'browser': None,
            'device_type': None
    }
    os = browser = device = "Unknown"

    # Detect iOS
    ios_match = re.search(r'iPhone.*OS (\d+_\d+_\d+)', ua)
    if ios_match:
        os = f"iOS {ios_match.group(1).replace('_', '.')}"
        device = "iPhone"
    
    # Safari version
    safari_match = re.search(r'Version/([\d\.]+).*Safari', ua)
    if safari_match:
        browser = f"Safari {safari_match.group(1)}"
    
    # Fallback for device
    if 'Mobile' in ua:
        device = "Mobile"
    elif 'iPad' in ua:
        device = "Tablet"
    elif 'Macintosh' in ua or 'Windows' in ua:
        device = "Desktop"

    return {
        'os': os,
        'browser': browser,
        'device_type': device
    }
@udf(returnType=ip_schema)
def ip_lookup(ip):
    if ip == "-1":
        return {
            "country": None,
            "region": None,
            "city": None
        }
    bin_path = SparkFiles.get("IP-COUNTRY-REGION-CITY.BIN")
    db = IP2Location.IP2Location(bin_path)
    if not ip:
        return None
    try:
        location = db.get_all(ip)  
        return {
            "country": location.country_long,
            "region": location.region,
            "city": location.city
        }
    except:
        return None

def write_df_to_postgres(df, table_name,schema_name,id):
    pandas_df = df.toPandas()

    # Connect to PostgreSQL
    conn = psycopg2.connect(
        dbname="project-06DB",
        user="postgres",
        password="admin",
        host="host.docker.internal",
        port=5432
    )
    cursor = conn.cursor()

    insert_sql = """
        INSERT INTO public.{table} {schema}
        VALUES %s
        ON CONFLICT ({primary_key}) DO NOTHING;
    """.format(table=table_name, schema=schema_name, primary_key=id)

    records = pandas_df.to_records(index=False).tolist()
    execute_values(cursor, insert_sql, records)
    conn.commit()
    cursor.close()
    conn.close()
def process_product_dim(batch_df, table_name, epoch_id):
    df_with_labels = batch_df.withColumn("product_id", when(col("product_id").isNull(), -1).otherwise(col("product_id")))

    if df_with_labels.rdd.isEmpty():
        return
    df_with_labels = df_with_labels.withColumn(
        "product_options",
        when(col("product_id") != -1, expr("transform(option, x -> x.option_label)"))
        .otherwise(lit(None))
    )
    df_with_labels = df_with_labels.withColumn("product_name", lit("Unknown Product"))
    processed_df = df_with_labels.select(col("product_id").cast("int").alias("product_id"), "product_name", "product_options")
    write_df_to_postgres(processed_df, table_name, "(product_id,product_name,product_options)", "product_id")

 
def process_user_dim(batch_df, table_name, epoch_id):
    processed_df = batch_df.withColumn(
            "user_id",
            when(col("email").isNotNull(), col("email"))
            .otherwise(sha2(concat_ws(":", col("device_id"), col("user_agent"), col("ip")), 256))
        ).select("user_id", "email").dropDuplicates(["user_id"])

    write_df_to_postgres(processed_df, table_name,"(user_id,email)", "user_id")

def process_device_dim(batch_df, table_name, epoch_id):
    filtered_df = batch_df.withColumn("device_id", when(col("device_id").isNull(), -1).otherwise(col("device_id")))
    enriched_df = filtered_df.withColumn("a", parser_user_agent("user_agent")) \
                            .select(col("device_id"), "a.device_type", "a.os", "a.browser", "user_agent") \

    write_df_to_postgres(enriched_df, table_name, "(device_id,device_type,os,browser,user_agent)", "device_id")

def process_time_dim(batch_df, table_name, epoch_id):
    dim_time_df = batch_df \
        .withColumn("time_id", when(col("local_time").isNotNull(),date_format(col("local_time"), "yyyyMMdd")).otherwise(lit("-1"))) \
        .withColumn("date", to_date(col("local_time"))) \
        .withColumn("hour", hour(col("local_time"))) \
        .withColumn("day_of_week", dayofweek(col("local_time"))) \
        .withColumn("month", month(col("local_time"))) \
        .withColumn("year", year(col("local_time"))) \
        .select("time_id", "date", "hour", "day_of_week", "month", "year") \
        .dropDuplicates(["time_id"])
    
    write_df_to_postgres(dim_time_df, table_name, "(time_id,date,hour,day_of_week,month,year)", "time_id")
    

def process_geography_dim(batch_df, table_name ,epoch_id,spark):
    filtered_df = batch_df.withColumn("ip", when(col("ip").isNull(), lit("0.0.0.0")).otherwise(col("ip")))
    enriched_df = filtered_df.withColumn("location", ip_lookup("ip")) \
                      .select("ip","location.country", "location.region", "location.city")


    write_df_to_postgres(enriched_df, table_name, "(ip, country, region, city)", "ip")
    
def process_store_dim(batch_df, table_name, epoch_id):
    filtered_df = batch_df.withColumn("store_id", when(col("store_id").isNull(), -1).otherwise(col("store_id")))
    if filtered_df.rdd.isEmpty():
        return
    if "store_id" in filtered_df.columns:
        filtered_df = filtered_df.withColumn("store_name", lit("Unknown store"))
        processed_df = filtered_df.select(col("store_id").cast("long").alias("store_id"), "store_name")
        write_df_to_postgres(processed_df, table_name, "(store_id,store_name)", "store_id")


def process_referrer_dim(batch_df, table_name, epoch_id):
    filtered_df = batch_df.withColumn("referrer_url", when(col("referrer_url").isNull(), None).otherwise(col("referrer_url")))
    filtered_df = filtered_df.withColumn("referer", parser_referer("referrer_url")) \
                             .select(
                                col("referrer_url"),
                                col("referer.domain").alias("domain"),
                                col("referer.full_url").alias("full_url"),
                                col("referer.source_type").alias("source_type")
                            ) \
                            .withColumn("referrer_id", when(col("referrer_url").isNotNull(),sha2(concat_ws("||", col("domain"), col("full_url"), col("source_type")), 256)).otherwise(lit("-1")))\
                            .drop("referrer_url")
    write_df_to_postgres(filtered_df, table_name, "(domain,full_url,source_type,referrer_id)", "referrer_id")
    return filtered_df

def process_fact_table(batch_df, epoch_id, dim_referrer):
    from pyspark.sql.functions import sha2, concat_ws, current_timestamp

    if batch_df.rdd.isEmpty():
        return

    # 1. Derive user_id as you did in dim_user
    fact_df = batch_df.withColumn(
        "user_id",
        when(col("email").isNotNull(), col("email"))
        .otherwise(sha2(concat_ws(":", col("device_id"), col("user_agent"), col("ip")), 256))
    )
    fact_df = fact_df.withColumn("full_url", col("referrer_url"))
    fact_df = fact_df.join(
        dim_referrer.select("full_url", "referrer_id"),
    on="full_url",
    how="left"
    )

    # 3. Get time_id
    fact_df = fact_df.withColumn("time_id", when(col("local_time").isNotNull(), date_format(col("local_time"), "yyyyMMdd")).otherwise("-1"))

    # 4. Clean fields for keys
    fact_df = fact_df.withColumn("product_id", when(col("product_id").isNull(), -1).otherwise(col("product_id")))
    fact_df = fact_df.withColumn("device_id", when(col("device_id").isNull(), -1).otherwise(col("device_id")))
    fact_df = fact_df.withColumn("store_id", when(col("store_id").isNull(), -1).otherwise(col("store_id")))
    fact_df = fact_df.withColumn("ip", when(col("ip").isNull(), "0.0.0.0").otherwise(col("ip")))

    # 5. Select the fact fields
    selected_fact_df = fact_df.select(
        col("id").alias("log_id"),
        col("user_id"),
        col("product_id").cast("long").alias("product_id"),
        col("device_id"),
        col("referrer_id"),
        col("store_id").cast("long").alias("store_id"),
        col("ip"),
        col("time_id"),
        col("current_url"),
        col("collection"),
        col("api_version")
    )

    write_df_to_postgres(selected_fact_df, "fact_product_view_log", "(log_id,user_id,product_id,device_id,referrer_id,store_id,ip,time_id,current_url,collection, api_version)", "log_id")

    


def process_kafka_messages(batch_df, epoch_id,spark):
    if batch_df.rdd.isEmpty():
        return
    process_store_dim(batch_df,"dim_store",epoch_id)
    process_geography_dim(batch_df, "dim_geography", epoch_id, spark)
    process_product_dim(batch_df, "dim_product",epoch_id)
    process_user_dim(batch_df, "dim_user", epoch_id)
    process_device_dim(batch_df, "dim_device", epoch_id)
    referrer_df = process_referrer_dim(batch_df, "dim_referrer", epoch_id)
    process_time_dim(batch_df,"dim_time", epoch_id)
    process_fact_table(batch_df,epoch_id, referrer_df)


